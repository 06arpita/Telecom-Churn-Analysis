CREATE VIEW vw_ChurnData AS
select * from prod_Churn where Customer_Status in ('Churned','Stayed');




CREATE VIEW vw_JoinData AS 
select * from prod_Churn where Customer_Status = 'Joined' 

select * from vw_ChurnData